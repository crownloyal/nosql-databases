#!/bin/bash
# # # # # # #
# INCLUDES  #
# # # # # # #
source ./var/common/find.sh
source ./var/common/findNode.sh
source ./var/common/math.sh

# # # # # # # # # # # # #
#  TEST AREA - DANGER   #
# # # # # # # # # # # # #

    LOGFILE=./var/logs/test.log
    LIST=""

    while read port; do
        writeToLog $LOGFILE "DEBUG: Current PORT :$port"
        LIST+="$HOSTLIST:$port"
    done < <(findAllMetaPorts)

    echo "$LIST"